import telebot
import webbrowser
from telebot import types
import random
import sqlite3
import requests
import  json
import datetime

bot = telebot.TeleBot('6597169776:AAHQ4mHUqbYR8AdxM9eUsNa_NLDSoXzBs6E')
API = '50f578af1e50875d5524be84e9a93816'
name = None

@bot.message_handler(commands=['start','привет','старт', 'hello', 'hi'])
def start(message):
    markup = types.ReplyKeyboardMarkup()
    btn1 = types.KeyboardButton('/weather')
    btn2 = types.KeyboardButton('/game')
    btn3 = types.KeyboardButton('/feedback')
    markup.row(btn1,btn2,btn3)
    file = open('./1613447280_8-p-fon-dlya-prezentatsii-pro-robotov-9.jpg','rb')
    bot.send_photo(message.chat.id, file,)
    bot.send_message(message.chat.id, f'Привет, {message.from_user.first_name}!', reply_markup=markup)


@bot.message_handler(commands=['site','website','feedback','вебсайт'])
def site(message):
    webbrowser.open('https://github.com/123kir/-3-')




@bot.message_handler(commands=['game'])
def site(message):
    bot.send_message(message.chat.id, f'{message.from_user.first_name},выбирите в какую игру хотите сыграть (Gamezero - это игра в "Крестики-Нолики",Gameone - это игра в "Камень Ножницы Бумага") :')
    markup = types.ReplyKeyboardMarkup()
    btn1 = types.KeyboardButton('/gamezero📄❌➖⭕️')
    btn2 = types.KeyboardButton('/gameone🪨✂️📄')
    markup.row(btn1, btn2)
    bot.send_message(message.chat.id, f'.', reply_markup=markup)


@bot.message_handler(commands=['gameone🪨✂️📄','gameone'])
def start(message):
    markup = types.ReplyKeyboardMarkup(row_width=3)
    markup.add(types.KeyboardButton('🪨'), types.KeyboardButton('✂️'), types.KeyboardButton('📄'))
    markup.add(types.KeyboardButton('/reset')) # Добавляем кнопку для обнуления очков
    bot.reply_to(message, "Добро пожаловать в игру 'Камень, ножницы, бумага'! Для игры используйте кнопки ниже:",
                 reply_markup=markup)


@bot.message_handler(func=lambda message: True)
def play_game(message):
    global score

    user_choice = message.text
    bot_choice = random.choice(['🪨', '✂️', '📄'])

    if user_choice not in ['🪨', '✂️', '📄', '/reset']: # Учитываем команду /reset
        bot.reply_to(message, "Пожалуйста, используйте кнопки для выбора камня, ножниц или бумаги.")
        return

    if user_choice == '/reset': # Обрабатываем команду /reset
        score = 0
        bot.reply_to(message, "Очки обнулены.")
        return

    if user_choice == bot_choice:
        bot.reply_to(message, f"Вы выбрали {user_choice}, а я выбрал {bot_choice}. Ничья!")
    elif (user_choice == '🪨' and bot_choice == '✂️') or (user_choice == '✂️' and bot_choice == '📄') or (
            user_choice == '📄' and bot_choice == '🪨'):
        score += 1
        bot.reply_to(message, f"Вы выбрали {user_choice}, а я выбрал {bot_choice}. Вы победили! 🎉")
    else:
        bot.reply_to(message, f"Вы выбрали {user_choice}, а я выбрал {bot_choice}. Я победил! 😄")

    bot.reply_to(message, text=f"Очки: {score}")


@bot.message_handler(commands=['score'])
def show_score(message):
    global score
    bot.reply_to(message, f"Текущие очки: {score}")


@bot.message_handler(commands=['weather'])
def site(message):
    bot.send_message(message.chat.id, f'{message.from_user.first_name},введи название города, в котором надо узнать погоду:')


@bot.message_handler(content_types=['text'])
def get_weather(message):
    city = message.text.strip().lower()
    res = requests.get(f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API}&units=metric')
    if res.status_code == 200:
        data = json.loads(res.text)
        temp = data["main"]["temp"]
        humidity = data["main"]["humidity"]
        pressure = data["main"]["pressure"]
        wind = data["wind"]["speed"]
        sunrise_timestamp = datetime.datetime.fromtimestamp(data["sys"]["sunrise"])
        sunset_timestamp = datetime.datetime.fromtimestamp(data["sys"]["sunset"])
        length_of_the_day = datetime.datetime.fromtimestamp(data["sys"]["sunset"]) - datetime.datetime.fromtimestamp(
            data["sys"]["sunrise"])
        code_to_smile = {
            "Clear": "Ясно \U00002600",
            "Clouds": "Облачно \U00002601",
            "Rain": "Дождь \U00002614",
            "Drizzle": "Дождь \U00002614",
            "Thunderstorm": "Гроза \U000026A1",
            "Snow": "Снег \U0001F328",
            "Mist": "Туман \U0001F32B"
        }
        weather_description = data["weather"][0]["main"]
        if weather_description in code_to_smile:
            wd = code_to_smile[weather_description]
        else:
            # если эмодзи для погоды нет, выводим другое сообщение
            wd = "Посмотри по вебкамерам, я не понимаю, что там за погода..."

        bot.reply_to(message, f'Сейчас все расскажу, {message.from_user.first_name}:')
        bot.reply_to(message, f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
                              f"Погода в городе: {city}\nТемпература: {temp}°C\n Осадки: {wd}\n"
                              f"Влажность: {humidity}%\nДавление: {(pressure / 1.333)} мм.рт.ст\nВетер: {wind} м/с \n"
                              f"Восход солнца: {sunrise_timestamp}\nЗакат солнца: {sunset_timestamp}\nПродолжительность дня: {length_of_the_day}\n"
                              f"Хорошего дня!")
    else:
        bot.reply_to(message, 'Город указан не верно!')

score = 0




# Словарь для хранения состояний игрового поля
game_board = {}


# Обработчик команды /start
@bot.message_handler(commands=['gamezero📄❌➖⭕️','gamezero'])
def start_game(message):
    chat_id = message.chat.id
    game_board[chat_id] = [[None, None, None],
                           [None, None, None],
                           [None, None, None]]
    draw_board(chat_id)
    bot.send_message(chat_id, 'Игра "крестики-нолики" началась! Чтобы сделать ход, введите номер ячейки от 1 до 9.')


# Обработчик текстовых сообщений (ходы игроков)
@bot.message_handler(func=lambda message: True)
def make_move(message):
    chat_id = message.chat.id
    player_move = int(message.text)
    row = (player_move - 1) // 3
    col = (player_move - 1) % 3

    # Проверка на валидность хода
    if not (1 <= player_move <= 9) or game_board[chat_id][row][col] is not None:
        bot.send_message(chat_id, 'Некорректный ход! Попробуйте еще раз.')
        return

    # Определение символа (крестик или нолик) для текущего игрока
    symbol = 'X' if count_moves(game_board[chat_id]) % 2 == 0 else 'O'

    # Обновление игрового поля
    game_board[chat_id][row][col] = symbol

    draw_board(chat_id)

    # Проверка на завершение игры
    if check_winner(game_board[chat_id], symbol):
        bot.send_message(chat_id, f'Вы победили!')
        del game_board[chat_id]
    elif count_moves(game_board[chat_id]) == 9:
        bot.send_message(chat_id, 'Игра закончилась вничью!')
        del game_board[chat_id]
    else:
        bot.send_message(chat_id, 'Ход противника...')
        bot.register_next_step_handler(message, bot_move)


# Ход бота
def bot_move(message):
    chat_id = message.chat.id
    empty_cells = []
    for i in range(3):
        for j in range(3):
            if game_board[chat_id][i][j] is None:
                empty_cells.append((i, j))
    if empty_cells:
        row, col = random.choice(empty_cells)
        game_board[chat_id][row][col] = 'O'
        draw_board(chat_id)

        # Проверка на завершение игры
        if check_winner(game_board[chat_id], 'O'):
            bot.send_message(chat_id, 'Бот победил!')
            del game_board[chat_id]
        elif count_moves(game_board[chat_id]) == 9:
            bot.send_message(chat_id, 'Игра закончилась вничью!')
            del game_board[chat_id]
    else:
        bot.send_message(chat_id, 'Ничья!')
        del game_board[chat_id]


# Функция для рисования игрового поля
def draw_board(chat_id):
    board = game_board[chat_id]
    board_str = ''
    for row in board:
        row_str = ' | '.join([symbol if symbol is not None else ' ' for symbol in row])
        board_str += row_str + '\n- - - - -\n'
    bot.send_message(chat_id, board_str)


# Функция для подсчета количество ходов на игровом поле
def count_moves(board):
    return sum(row.count(symbol) for row in board for symbol in row if symbol is not None)


# Функция для проверки победителя
def check_winner(board, symbol):
    for row in board:
        if row[0] == row[1] == row[2] == symbol:
            return True
    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] == symbol:
            return True
    if board[0][0] == board[1][1] == board[2][2] == symbol:
        return True
    if board[0][2] == board[1][1] == board[2][0] == symbol:
        return True
    return False


bot.polling()


bot.polling(none_stop=True)